import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Millonaire here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Millonaire extends Actor
{
    /**
     * Act - do whatever the Millonaire wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    

    
    public Millonaire(int cantidad){
          setRotation(cantidad);
        }
    public void act()
    {
        if(Greenfoot.isKeyDown("left")){
            setLocation(getX()-5, getY());
        }
        if(Greenfoot.isKeyDown("right")){
            setLocation(getX()+5, getY());
        }
        if(Greenfoot.isKeyDown("down")){
            setLocation(getY()+5, getX());
        }
        if(Greenfoot.isKeyDown("up")){
            setLocation(getY()-5, getX());
        }
        
       // Add your action code here.
    }
}
